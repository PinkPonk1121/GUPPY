import random

emoji = ['<:fillow:782947475061211137>', '<:chicalit:782981070176911411>', '<:hedgeroc:782983223768383498>',
         '<:kitsunni:782982459145977916>', '<:dianny:782981070102331402>', '<:flutterbug:782981069988560897>']
print(random.choice(emoji))